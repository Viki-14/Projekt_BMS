/*
 * functions.h
 *
 *  Created on: May, 2025
 *      Author: AlexP
 */

#include "main.h"
#include <stdbool.h>
#include <string.h>

#ifndef INC_FUNCTIONS_H_
#define INC_FUNCTIONS_H_

//Externe Variablen für Temperatur
extern float tempValues[6];
extern uint16_t adcValue_temp[6];
extern float TempMeasurement1;
extern float TempMeasurement2;
extern float TempMeasurement3;
extern float TempMeasurement4;
extern float TempMeasurement5;
extern float TempMeasurement6;
extern float avg_tempValues[6];

//Externe Variablen für Voltage
extern uint16_t adcValue_voltage[4];
extern float voltageValues[4];
extern float VoltageMeasurement1;
extern float VoltageMeasurement2;
extern float VoltageMeasurement3;
extern float VoltageMeasurement4;
extern float avg_voltageValues[4];

//Threshold-Values
extern float ThresholdVoltageLow;
extern float ThresholdVoltageHigh;
extern float ThresholdTempLow;
extern float ThresholdTempHigh;
extern float ThresholdCurrentLow;
extern float ThresholdCurrentHigh;

//Externe Variablen für Current
extern float CurrentMeasurement;
extern uint16_t adcValue_current_display[3];
extern float currentValue;
extern float avg_currentValue;

//Externe Vairablen für Display
extern float touchdisplay_x;
extern float touchdisplay_y;
/*
//State Übergabe
enum SystemState{
    STATE_INIT,
    STATE_FAULT,
    STATE_IDLE,
    STATE_PRECHARGE,
    STATE_ACTIVE
};
extern enum SystemState State;
*/

//Fehlerflags
extern bool acc_error;
extern bool voltage_error;
extern bool temperature_error;
extern bool current_error;

//Relais_control
void Precharge(void);
void Relais_plus(void);
void Relais_minus(void);

//Voltage_Measurment
float Voltage_Measurement(float Vout_measured);

//Temp_Measurment
float Temp_Measurement(float Vout_measured);

//Current_Measurment
float Current_Measurement(float Vout_measured);

//12Bit to Voltage
float Bit_to_Voltage(uint16_t adc_value);

//Treshhold Vergleich
void check_limits(float* avg_values, char typ, int size, float min, float max);

//Callbackfunction
void HAL_ADC_ConvCpltCallback(ADC_HandleTypeDef* hadc);

#endif /* INC_FUNCTIONS_H_ */

// Buffer Functions
struct Module {
    struct RingBuffer** buff;
    float* avg;
    int size;
};

struct RingBuffer {
    float* arr;
    float sum;
    char full;
    int i;
};

void buff_push_val(struct RingBuffer* buff, float val);

float buff_get_avg(struct RingBuffer* buff);

struct Module* create_module(int size);

void mod_push(struct Module* mod, float* arr);

void free_mod(struct Module* mod);

void initialize_modules(void);

void free_modules();

float* push(float* arr, char type);



//buffer end
