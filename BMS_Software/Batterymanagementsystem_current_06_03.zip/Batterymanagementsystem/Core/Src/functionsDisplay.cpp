/*
 * functionsDisplay.cpp
 *
 *  Created on: May, 2025
 *      Author: kevin
 */

#include "Display_Header/functionsDisplay.hpp"
#include <Display_Header/Adafruit_HX8357.hpp>
#include "Display_Header/gfxfont.h"
#include <Display_Header/Adafruit_SPITFT_Macros.hpp>
#include <Display_Header/IO.hpp>
#include <Display_Header/SPI.hpp>
#include <Display_Header/Print.hpp>
#include "Display_Header/Adafruit_GFX.hpp"
#include "stm32f4xx_hal.h"
#include "Display_Header/XPT2046_newCpp.hpp"
#include "main.h"


//Display - Initialization via Constructor
IO dc  = IO(TFT_DC_PORT,TFT_DC_PIN);
IO rst = IO(GPIOD,GPIO_PIN_3);
SPI spi(SPI::PORT_SPI1);
Adafruit_HX8357 display = Adafruit_HX8357(&spi, &dc, &rst, HX8357D);

//Threshold-Values
float THRESHOLDVOLTAGELOW = 2.55f;
float THRESHOLDVOLTAGEHIGH = 4.15f;
float THRESHOLDTEMPLOW = 0.0f;
float THRESHOLDTEMPHIGH = 50.0f;
float THRESHOLDCURRENTLOW = -9.0f;
float THRESHOLDCURRENTHIGH = 90.0f;


//State
typedef enum {
    STATE_INIT,
    STATE_FAULT,
    STATE_IDLE,
    STATE_PRECHARGE,
    STATE_ACTIVE
} SystemState;


//Runtime
uint32_t runTime_ms = HAL_GetTick();
uint32_t runTime_s = runTime_ms / 1000;


/**************************************************************************/
/*!
   @brief	Function in order to print permanent text
*/
/**************************************************************************/
void drawUI(){
	 display.begin(HX8357D);
	 display.setRotation(1);

	//Standard settings
	 display.fillScreen(HX8357_BLACK);
	 display.setTextColor(HX8357_WHITE);
	 display.setTextSize(1);

	 //Measurments
	 display.setCursor(8, 5);
	 display.print("MEASUREMENT");
	 display.drawRect(14, 16,163-14, 210-16, HX8357_WHITE);

	 //Voltages
	 display.setCursor(23, 24);
	 display.print("VOLTAGES");
	 for(int i=0; i<4; i++){
		 display.setCursor(37, 37+i*11);
		 display.print("CELL ");
		 display.print(i+1);
	 }
	 display.setCursor(37,81);
	 display.print("OVERALL");
	 for(int i=0; i<5; i++){
		 display.setCursor(146,37+i*11);
		 display.print("V");
	 }

	 //Current
	 display.setCursor(24,98);
	 display.print("CURRENT");
	 display.setCursor(37, 111);
	 display.print("OVERALL");
	 display.setCursor(147, 111);
	 display.print("A");

	 //Temperatures
	 display.setCursor(24, 128);
	 display.print("TEMPERATURES");
	 for(int i=0; i<6; i++){
		 display.setCursor(37, 141+i*11);
		 display.print("TAP ");
		 display.print(i+1);
	 }
	 for(int i=0; i<6; i++){
			 display.setCursor(143, 141+i*11);
			 display.print("°C");
	}

	 //Contactor
	 display.setCursor(187, 5);
	 display.print("CONTACTOR");
	 display.drawRect(192, 16, 307-192, 141-16, HX8357_WHITE);
	 display.setCursor(200, 24);
	 display.print("CURRENTLY: ");

	 //Status
	 display.setCursor(187, 151);
	 display.print("STATUS");
	 display.drawRect(192, 163, 307-192, 184-163, HX8357_WHITE);

	 //Runtime
	 display.setCursor(187, 197);
	 display.print("RUNTIME");
	 display.drawRect(192, 209, 307-192, 231-209, HX8357_WHITE);
	 display.setCursor(237, 218);
	 display.print(":");
	 display.setCursor(263, 218);
	 display.print(":");
}

/**************************************************************************/
/*!
   @brief	Function in order to print voltage values
*/
/**************************************************************************/
void drawVoltagesUI(float VoltageMeasurement1, float VoltageMeasurement2, float VoltageMeasurement3,float VoltageMeasurement4, float VoltageMeasurementTotal){			// to include in while loop for permanent change
	// Voltage 1
	display.setCursor(92, 37);
	if (VoltageMeasurement1 > THRESHOLDVOLTAGEHIGH || VoltageMeasurement1 < THRESHOLDVOLTAGELOW){
		display.setTextColor(HX8357_RED);
		display.print(VoltageMeasurement1);
	}
	else{
		display.setTextColor(HX8357_GREEN);
		display.print(VoltageMeasurement1);
	}

	// Voltage 2
	display.setCursor(92, 48);
	if (VoltageMeasurement2 > THRESHOLDVOLTAGEHIGH || VoltageMeasurement2 < THRESHOLDVOLTAGELOW){
		display.setTextColor(HX8357_RED);
		display.print(VoltageMeasurement2);
	}
	else{
		display.setTextColor(HX8357_GREEN);
		display.print(VoltageMeasurement2);
	}

	// Voltage 3
	display.setCursor(92, 59);
	if (VoltageMeasurement3 > THRESHOLDVOLTAGEHIGH || VoltageMeasurement3 < THRESHOLDVOLTAGELOW){
		display.setTextColor(HX8357_RED);
		display.print(VoltageMeasurement3);
	}
	else{
		display.setTextColor(HX8357_GREEN);
		display.print(VoltageMeasurement3);
	}

	// Voltage 4
	display.setCursor(92, 70);
	if (VoltageMeasurement4 > THRESHOLDVOLTAGEHIGH || VoltageMeasurement4 < THRESHOLDVOLTAGELOW){
		display.setTextColor(HX8357_RED);
		display.print(VoltageMeasurement4);
	}
	else{
		display.setTextColor(HX8357_GREEN);
		display.print(VoltageMeasurement4);
	}

	// Voltage Total
	display.setCursor(92, 37);
	//if (VoltageMeasurementTotal > THRESHOLDVOLTAGEHIGH || VoltageMeasurementTotal < THRESHOLDVOLTAGELOW){
		display.setTextColor(HX8357_BLUE);
		display.print(VoltageMeasurementTotal);
	//}
	//else{
		display.setTextColor(HX8357_BLUE);
		display.print(VoltageMeasurementTotal);
	//}
}

/**************************************************************************/
/*!
   @brief	Function in order to print temperature values
*/
/**************************************************************************/
void drawTemperaturesUI(float TempMeasurement1, float TempMeasurement2, float TempMeasurement3, float TempMeasurement4, float TempMeasurement5, float TempMeasurement6){
	//Temperature 1
	display.setCursor(92, 141);
	if (TempMeasurement1 > THRESHOLDTEMPHIGH || TempMeasurement1 < THRESHOLDTEMPLOW){
		display.setTextColor(HX8357_RED);
		display.print(TempMeasurement1);
	}
	else{
		display.setTextColor(HX8357_GREEN);
		display.print(TempMeasurement1);
	}

	//Temperature 2
	display.setCursor(92, 152);
	if (TempMeasurement2 > THRESHOLDTEMPHIGH || TempMeasurement2 < THRESHOLDTEMPLOW){
		display.setTextColor(HX8357_RED);
		display.print(TempMeasurement2);
	}
	else{
		display.setTextColor(HX8357_GREEN);
		display.print(TempMeasurement2);
	}

	//Temperature 3
	display.setCursor(92, 163);
	if (TempMeasurement3 > THRESHOLDTEMPHIGH || TempMeasurement3 < THRESHOLDTEMPLOW){
		display.setTextColor(HX8357_RED);
		display.print(TempMeasurement3);
	}
	else{
		display.setTextColor(HX8357_GREEN);
		display.print(TempMeasurement3);
	}

	//Temperature 4
	display.setCursor(92, 174);
	if (TempMeasurement4 > THRESHOLDTEMPHIGH || TempMeasurement4 < THRESHOLDTEMPLOW){
		display.setTextColor(HX8357_RED);
		display.print(TempMeasurement4);
	}
	else{
		display.setTextColor(HX8357_GREEN);
		display.print(TempMeasurement4);
	}

	//Temperature 5
	display.setCursor(92, 185);
	if (TempMeasurement5 > THRESHOLDTEMPHIGH || TempMeasurement5 < THRESHOLDTEMPLOW){
		display.setTextColor(HX8357_RED);
		display.print(TempMeasurement5);
	}
	else{
		display.setTextColor(HX8357_GREEN);
		display.print(TempMeasurement5);
	}

	//Temperature 6
	display.setCursor(92, 196);
	if (TempMeasurement6 > THRESHOLDTEMPHIGH || TempMeasurement6 < THRESHOLDTEMPLOW){
		display.setTextColor(HX8357_RED);
		display.print(TempMeasurement6);
	}
	else{
		display.setTextColor(HX8357_GREEN);
		display.print(TempMeasurement6);
	}
}

/**************************************************************************/
/*!
   @brief	Function in order to print current value
*/
/**************************************************************************/
void drawCurrentUI(float CurrentMeasurement){
	//Current
	display.setCursor(92, 111);
	if (CurrentMeasurement > THRESHOLDCURRENTHIGH || CurrentMeasurement < THRESHOLDCURRENTLOW){
		display.setTextColor(HX8357_RED);
		display.print(CurrentMeasurement);
	}
	else{
		display.setTextColor(HX8357_GREEN);
		display.print(CurrentMeasurement);
	}
}

/**************************************************************************/
/*!
   @brief	Function in order to print system state
*/
/**************************************************************************/
void drawStatusUI(SystemState State){

	//State
	display.setCursor(228, 171);
	display.setTextColor(HX8357_WHITE);
	display.print(State);
}

/**************************************************************************/
/*!
   @brief	Function in order to print running time HH:MM:SS
*/
/**************************************************************************/
void drawRuntimeUI(uint32_t runTime_s){
	//Calculation
	uint32_t hours = 0;
	uint32_t minutes = 0;
	uint32_t seconds = 0;

	seconds = runTime_s % 60;
	if (seconds == 0){
		minutes++;
	}
	if (minutes == 60){
		hours++;
		minutes = 0;
	}

	display.setTextColor(HX8357_WHITE);

	//Hours
	display.setCursor(217, 218);
	display.print(hours);

	//Minutes
	display.setCursor(243, 218);
	display.print(minutes);

	//Seconds
	display.setCursor(269, 218);
	display.print(seconds);
}

/**************************************************************************/
/*!
   @brief	Button functions - Definitions
*/
/**************************************************************************/
//extern XPT2046_Touchscreen getTouch(); // Funktion, um Touch-Punkt abzufragen

#define BUTTON_WIDTH 62
#define BUTTON_HEIGHT 32
#define COLOR_BUTTON_ACTIVE HX8357_CYAN
#define COLOR_BUTTON_INACTIVE HX8357_DARK_GREY

/**************************************************************************/
/*!
   @brief	Button functions - Initialisation
*/
/**************************************************************************/
Adafruit_GFX_Button buttonOn;
Adafruit_GFX_Button buttonOff;
//bool ButtonContactor = false;
XPT2046Touch touch(&hspi1, GPIOD, GPIO_PIN_6);

/**************************************************************************/
/*!
   @brief	Button functions - SetUp and Drawing
*/
/**************************************************************************/
void setupButtons() {
  buttonOn.initButton(&display, 219, 44, BUTTON_WIDTH, BUTTON_HEIGHT, HX8357_WHITE, COLOR_BUTTON_ACTIVE, HX8357_WHITE, (char*)"ON", 1);
  buttonOff.initButton(&display, 219, 93, BUTTON_WIDTH, BUTTON_HEIGHT, HX8357_WHITE, COLOR_BUTTON_INACTIVE, HX8357_WHITE, (char*)"OFF", 1);
  buttonOn.drawButton(!ButtonContactor);
  buttonOff.drawButton(ButtonContactor);
}

/**************************************************************************/
/*!
   @brief	Button functions - Touch Point on display
*/
/**************************************************************************/
struct TouchPoint{
	uint16_t x;
	uint16_t y;
	uint16_t z;
};

TouchPoint getTouch() {
    TouchPoint p{0, 0, 0};
    uint16_t x, y;
    if (touch.getTouch(x, y)) {
        p.x = x;
        p.y = y;
        p.z = 200; // Simulierter Druckwert, wenn Berührung erkannt
    }
    return p;
}

/**************************************************************************/
/*!
   @brief	Button functions - Check if Button was pressed
*/
/**************************************************************************/
void checkButtons() {
    TouchPoint p = getTouch();
    if (p.z > 100) {  // einfache Schwelle
        if (!ButtonContactor && buttonOn.contains(p.x, p.y)) {
        	ButtonContactor = true;
            setupButtons();
        } else if (ButtonContactor && buttonOff.contains(p.x, p.y)) {
        	ButtonContactor = false;
            setupButtons();
        }
    }
}


