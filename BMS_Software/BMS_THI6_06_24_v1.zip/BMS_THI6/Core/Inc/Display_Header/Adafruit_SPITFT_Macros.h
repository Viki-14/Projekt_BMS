/*
 * Adafruit_SPITFT_Macros.h
 *
 * Link: https://github.com/mindThomas/STM32-libraries/blob/master/Drivers/LCD/Adafruit_SPITFT_Macros.h
 *
 *  Created on: Jun 16, 2025
 *      Author: kevin
 */

#ifndef INC_DISPLAY_HEADER_ADAFRUIT_SPITFT_MACROS_H_
#define INC_DISPLAY_HEADER_ADAFRUIT_SPITFT_MACROS_H_

#include "stm32f4xx_hal.h"

//SPI Handle
extern SPI_HandleTypeDef hspi1;

//Definition Steuerleitungen
#define TFT_DC_PORT      GPIOD
#define TFT_DC_PIN       GPIO_PIN_7

#define TFT_CS_PORT      GPIOD
#define TFT_CS_PIN       GPIO_PIN_6

#define TFT_MOSI_PORT    GPIOB
#define TFT_MOSI_PIN     GPIO_PIN_5

#define TFT_RST_PORT     GPIOD
#define TFT_RST_PIN      GPIO_PIN_3

//Makros zum Setzen/Zurücksetzen von Pins
#define SPI_DC_HIGH()   HAL_GPIO_WritePin(TFT_DC_PORT, TFT_DC_PIN, GPIO_PIN_SET)
#define SPI_DC_LOW()    HAL_GPIO_WritePin(TFT_DC_PORT, TFT_DC_PIN, GPIO_PIN_RESET)

#define SPI_CS_HIGH()   HAL_GPIO_WritePin(TFT_CS_PORT, TFT_CS_PIN, GPIO_PIN_SET)
#define SPI_CS_LOW()    HAL_GPIO_WritePin(TFT_CS_PORT, TFT_CS_PIN, GPIO_PIN_RESET)

//SPI Transaktionen
#define HSPI_BEGIN_TRANSACTION()    SPI_CS_LOW()
#define HSPI_END_TRANSACTION()      SPI_CS_HIGH()

#define HSPI_WRITE(b) \
    do { uint8_t _b = (b); HAL_SPI_Transmit(&hspi1, &_b, 1, SPI_TIMEOUT); } while(0)		//changed HAL_MAX_DELAY to SPI_TIMEOUT

#define HSPI_WRITE16(s) \
    do { uint8_t _data[2] = { uint8_t((s) >> 8), uint8_t((s) & 0xFF) }; \
         HAL_SPI_Transmit(&hspi1, _data, 2, HAL_MAX_DELAY); } while(0)

#define HSPI_WRITE32(l) \
    do { uint8_t _data[4] = { uint8_t((l) >> 24), uint8_t((l) >> 16), \
                              uint8_t((l) >> 8), uint8_t((l)); \
         HAL_SPI_Transmit(&hspi1, _data, 4, HAL_MAX_DELAY); } while(0)

#define HSPI_READ() ({ \
    uint8_t _rx = 0xFF, _tx = 0x00; \
    HAL_SPI_TransmitReceive(&hspi1, &_tx, &_rx, 1, HAL_MAX_DELAY); \
    _rx; })

//Optimiertes Pixel-Schreiben
#define SPI_MAX_PIXELS_AT_ONCE  32
#define HSPI_WRITE_PIXELS(c, l) \
    HAL_SPI_Transmit(&hspi1, (uint8_t*)(c), (l), HAL_MAX_DELAY)

//Aliase
#define SPI_BEGIN_TRANSACTION()   HSPI_BEGIN_TRANSACTION()
#define SPI_END_TRANSACTION()     HSPI_END_TRANSACTION()
#define SPI_WRITE16(s)            HSPI_WRITE16(s)
#define SPI_WRITE32(l)            HSPI_WRITE32(l)
#define SPI_WRITE_PIXELS(c, l)    HSPI_WRITE_PIXELS(c, l)

#endif /* INC_DISPLAY_HEADER_ADAFRUIT_SPITFT_MACROS_H_ */
