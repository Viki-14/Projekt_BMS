/*
 * functionsDisplay.h
 *
 *  Created on: Jun 16, 2025
 *      Author: kevin
 */

#ifndef INC_DISPLAY_HEADER_FUNCTIONSDISPLAY_H_
#define INC_DISPLAY_HEADER_FUNCTIONSDISPLAY_H_

#include <stdint.h>
#include <stddef.h>
#include "Display_Header/IO.h"
#include "Display_Header/SPI.h"
#include "Display_Header/Adafruit_ILI9341.h"

class functionsDisplay{

	public:
		struct TouchPoint{
			uint16_t x;
			uint16_t y;
			uint16_t z;
		};
	private:
		typedef enum {
			STATE_INIT,
			STATE_FAULT,
			STATE_IDLE,
			STATE_PRECHARGE,
			STATE_ACTIVE
		} SystemState;

	public:
		IO dc;
		IO rst;
		IO mosi;
		IO cs;
		SPI spi;
		Adafruit_ILI9341* display;

	public:
		functionsDisplay(void);
		void initializeDisplay(void);
		void drawUI(void);
		void drawVoltagesUI(float VoltageMeasurement1, float VoltageMeasurement2, float VoltageMeasurement3,float VoltageMeasurement4, float VoltageMeasurementTotal);
		void drawTemperaturesUI(float TempMeasurement1, float TempMeasurement2, float TempMeasurement3, float TempMeasurement4, float TempMeasurement5, float TempMeasurement6);
		void drawCurrentUI(float CurrentMeasurement);
		void drawStatusUI(SystemState State);
		void drawRuntimeUI(uint32_t runTime_s);
		void setupButtons(bool ButtonContactor);
		TouchPoint getTouch();
		bool checkButtons();
};

#endif /* INC_DISPLAY_HEADER_FUNCTIONSDISPLAY_H_ */
