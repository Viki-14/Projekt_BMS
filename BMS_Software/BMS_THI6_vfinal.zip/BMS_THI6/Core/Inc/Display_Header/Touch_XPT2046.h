/*
 * Touch_XPT2046.h
 *
 *  Created on: Jun 16, 2025
 *      Author: kevin
 */

#ifndef INC_DISPLAY_HEADER_TOUCH_XPT2046_H_
#define INC_DISPLAY_HEADER_TOUCH_XPT2046_H_

#include "stm32f4xx_hal.h"

class XPT2046Touch {
public:
    XPT2046Touch(SPI_HandleTypeDef* hspi, GPIO_TypeDef* csPort, uint16_t csPin);
    void begin();
    bool isTouched();
    bool getTouch(uint16_t& x, uint16_t& y);

private:
    uint16_t readCoordinate(uint8_t command);
    void select();
    void deselect();

    SPI_HandleTypeDef* _hspi;
    GPIO_TypeDef* _csPort;
    uint16_t _csPin;
};

#endif /* INC_DISPLAY_HEADER_TOUCH_XPT2046_H_ */
