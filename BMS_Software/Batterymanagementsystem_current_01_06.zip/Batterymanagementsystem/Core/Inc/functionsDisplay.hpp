/*
 * functionsDisplay.hpp
 *
 *  Created on: May 27, 2025
 *      Author: kevin
 */

#ifndef INC_FUNCTIONSDISPLAY_HPP_
#define INC_FUNCTIONSDISPLAY_HPP_


void Display_Configuration(void);


#endif /* INC_FUNCTIONSDISPLAY_HPP_ */
