/*
 * functions.c
 *
 *  Created on: May, 2025
 *      Author: AlexP
 */

#include "functions.h"
#include <stdbool.h>
#include <math.h>

//Precharge Relais Ansteuerung
/*
void Relais_control(void)
  {
	  HAL_GPIO_TogglePin(GPIOD, GPIO_PIN_0);   // Setzt PIN PD0 auf 1 (high)
  }


//Voltage_Measurement



//Temp_Measurment

float Temp_Measurement(float Vout_measured) {

    float Rfix = 10000.0f;
    float Vcc = 5.0f; // Versorgung des Spannungsteilers
    float Vout_corrected = 0;
    float Rntc = 0;
    float tempK = 0;
    float T0 = 298.15f;  // 25 °C in Kelvin
    float R0 = 10000.0f; // 10k bei 25 °C
    float B  = 3892.0f;  // Beta-Wert

    //Spannungskorrektur
    Vout_corrected = 2 * Vout_measured;

    //Berechnung R_NTC
    Rntc = (Vout_corrected * Rfix / Vcc - Vout_corrected) - Rfix;

    tempK = 1.0f / ((1.0f / T0) + (1.0f / B) * log(Rntc / R0));
    return tempK - 273.15f; // Umrechnung in °C
}


//Current_Measurement


*/



//Display_Configuration
#include "Adafruit_HX8357.h"
#include "gfxfont.h"
#include "Adafruit_SPITFT_Macros.h"
#include "IO.h"
#include "SPI.h"

//Display tft - Initialization via Constructor
IO dc  = IO(TFT_DC_PORT,TFT_DC_PIN);
IO rst = IO(GPIOD,GPIO_PIN_3);
SPI spi = SPI(&hspi1);
Adafruit_HX8357 tft = Adafruit_HX8357(spi, &dc, &rst, HX8357D);

//Function in order to print permanent text
void drawUI(){
	//Standard settings
	 tft.fillScreen(HX8357_BLACK);
	 tft.setTextColor(HX8357_WHITE);
	 tft.setTextSize(1);

	 //Measurments
	 tft.setCursor(8, 5);
	 tft.print("MEASUREMENTS");
	 tft.drawRect(14, 16,163-14, 210-16, HX8357_WHITE);

	 //Voltages
	 tft.setCursor(23, 24);
	 tft.print("VOLTAGES");
	 for(int i=0; i<4; i++){
		 tft.setCursor(37, 37+i*11);
		 tft.print("CELL ");
		 tft.print(i+1);
	 }
	 tft.setCursor(37,81);
	 tft.print("OVERALL");
	 for(int i=0; i<5; i++){
		 tft.setCursor(146,37+i*11);
		 tft.print("V");
	 }

	 //Current
	 tft.setCursor(24,98);
	 tft.print("CURRENT");
	 tft.setCursor(37, 111);
	 tft.print("OVERALL");
	 tft.setCursor(147, 111);
	 tft.print("A");

	 //Temperatures
	 tft.setCursor(24, 128);
	 tft.print("TEMPERATURES");
	 for(int i=0; i<6; i++){
		 tft.setCursor(37, 141+i*11);
		 tft.print("TAP ");
		 tft.print(i+1);
	 }
	 for(int i=0; i<6; i++){
			 tft.setCursor(143, 141+i*11);
			 tft.print("°C");
	}

	 //Contactor
	 tft.setCursor(187, 5);
	 tft.print("CONTACTOR");
	 tft.drawRect(192, 16, 307-192, 141-16, HX8357_WHITE);
	 tft.setCursor(200, 24);
	 tft.print("CURRENTLY: ");

	 //Status
	 tft.setCursor(187, 151);
	 tft.print("STATUS");
	 tft.drawRect(192, 163, 307-192, 184-163, HX8357_WHITE);

	 //Runtime
	 tft.setCursor(187, 197);
	 tft.print("RUNTIME");
	 tft.drawRect(192, 209, 307-192, 231-209, HX8357_WHITE);
	 tft.setCursor(237, 218);
	 tft.print(":");
	 tft.setCursor(263, 218);
	 tft.print(":");
}



