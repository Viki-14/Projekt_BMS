/*
 * Touch.cpp
 *
 *  Created on: May 26, 2025
 *      Author: kevin
 */

#include "stm32f4xx.h"


// Resistive Touchscreen
void Touch_Init(void) {
    RCC->AHB1ENR |= RCC_AHB1ENR_GPIOEEN;
    RCC->APB2ENR |= RCC_APB2ENR_ADC1EN;

    // ADC config nur rudimentär
    ADC1->CR2 |= ADC_CR2_ADON;
}

// TODO: Dummy Beispiel für Touch-X Messung an PE4 (Auf Nutzung noch anzupassen)
uint16_t Touch_ReadX(void) {
    // PE6 High, PE4 als ADC input
    GPIOE->MODER |= (3 << (4 * 2)); // PE4 analog
    GPIOE->MODER |= (1 << (6 * 2)); // PE6 output
    GPIOE->ODR |= (1 << 6);

    // ADC auf Kanal PE4 (ADC_IN4 bei STM32F4 Discovery)
    ADC1->SQR3 = 4;
    ADC1->CR2 |= ADC_CR2_SWSTART;
    while (!(ADC1->SR & ADC_SR_EOC));
    return ADC1->DR;
}
