/*
 * functions.c
 *
 *  Created on: May, 2025
 *      Author: kevin
 */

#include "functionsDisplay.hpp"

//Display_Configuration
#include <Display_Header/Adafruit_HX8357.hpp>
#include "Display_Header/gfxfont.h"
#include <Display_Header/Adafruit_SPITFT_Macros.hpp>
#include <Display_Header/IO.hpp>
#include <Display_Header/SPI.hpp>

//Display tft - Initialization via Constructor
IO dc  = IO(TFT_DC_PORT,TFT_DC_PIN);
IO rst = IO(GPIOD,GPIO_PIN_3);
SPI spi(SPI::PORT_SPI1);
Adafruit_HX8357 display = Adafruit_HX8357(&spi, &dc, &rst, HX8357D);

//Function in order to print permanent text
void drawUI(){
	//Standard settings
	 display.fillScreen(HX8357_BLACK);
	 display.setTextColor(HX8357_WHITE);
	 display.setTextSize(1);

	 //Measurments
	 display.setCursor(8, 5);
	 display.print("MEASUREMENTS");
	 display.drawRect(14, 16,163-14, 210-16, HX8357_WHITE);

	 //Voltages
	 display.setCursor(23, 24);
	 display.print("VOLTAGES");
	 for(int i=0; i<4; i++){
		 display.setCursor(37, 37+i*11);
		 display.print("CELL ");
		 display.print(i+1);
	 }
	 display.setCursor(37,81);
	 display.print("OVERALL");
	 for(int i=0; i<5; i++){
		 display.setCursor(146,37+i*11);
		 display.print("V");
	 }

	 //Current
	 display.setCursor(24,98);
	 display.print("CURRENT");
	 display.setCursor(37, 111);
	 display.print("OVERALL");
	 display.setCursor(147, 111);
	 display.print("A");

	 //Temperatures
	 display.setCursor(24, 128);
	 display.print("TEMPERATURES");
	 for(int i=0; i<6; i++){
		 display.setCursor(37, 141+i*11);
		 display.print("TAP ");
		 display.print(i+1);
	 }
	 for(int i=0; i<6; i++){
			 display.setCursor(143, 141+i*11);
			 display.print("°C");
	}

	 //Contactor
	 display.setCursor(187, 5);
	 display.print("CONTACTOR");
	 display.drawRect(192, 16, 307-192, 141-16, HX8357_WHITE);
	 display.setCursor(200, 24);
	 display.print("CURRENTLY: ");

	 //Status
	 display.setCursor(187, 151);
	 display.print("STATUS");
	 display.drawRect(192, 163, 307-192, 184-163, HX8357_WHITE);

	 //Runtime
	 display.setCursor(187, 197);
	 display.print("RUNTIME");
	 display.drawRect(192, 209, 307-192, 231-209, HX8357_WHITE);
	 display.setCursor(237, 218);
	 display.print(":");
	 display.setCursor(263, 218);
	 display.print(":");
}



