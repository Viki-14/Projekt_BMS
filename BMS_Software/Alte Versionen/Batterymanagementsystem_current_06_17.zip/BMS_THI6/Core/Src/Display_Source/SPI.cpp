/*
 * SPI.cpp
 *
 *  Created on: Jun 16, 2025
 *      Author: kevin
 */
/*
#include "Display_Header/SPI.h"
#include "stm32f4xx.h"

SPI::SPI(SPI_HandleTypeDef* spiHandle) {
    _spi = spiHandle;
}

void SPI::init() {
    // Optional: SPI initialization if not done via CubeMX
    // HAL_SPI_Init(_spi); // Uncomment if needed
}

void SPI::write(uint8_t data) {
    HAL_SPI_Transmit(_spi, &data, 1, HAL_MAX_DELAY);
}

uint8_t SPI::transfer(uint8_t data) {
    uint8_t received = 0;
    HAL_SPI_TransmitReceive(_spi, &data, &received, 1, HAL_MAX_DELAY);
    return received;
}

void SPI::writeBuffer(uint8_t* buffer, uint16_t size) {
    HAL_SPI_Transmit(_spi, buffer, size, HAL_MAX_DELAY);
}

void SPI::flush() {
    __HAL_SPI_CLEAR_OVRFLAG(_spi);
    __HAL_SPI_CLEAR_FREFLAG(_spi);
}

uint8_t SPI::read() {
    uint8_t dummy = 0xFF;
    uint8_t received = 0;
    HAL_SPI_TransmitReceive(_spi, &dummy, &received, 1, HAL_MAX_DELAY);
    return received;
}
*/
/*
 * SPI.cpp
 *
 *  Created on: May 23, 2025
 *      Author: kevin
 */

#include "stm32f4xx.h"
#include "Display_Header/SPI.h"

// === Pin Mapping ===
// SPI1: PA5 = SCK, PB5 = MOSI, PD6 = CS, PD7 = DC, PD3 = RST
// Touch: PE4 = X-, PE6 = Y-, PC2 = X+, PC3 = Y+


SPI::hardware_resource_t * SPI::resSPI1 = nullptr;
static SPI_HandleTypeDef hspi1;

uint32_t SPI::get_spi1_clock_freq(void) {
    RCC_ClkInitTypeDef clkconfig;
    uint32_t flashLatency;
    HAL_RCC_GetClockConfig(&clkconfig, &flashLatency);

    // PCLK2 responsible for SPI1
    uint32_t pclk = HAL_RCC_GetPCLK2Freq();

    // Read prescaler from SPI-Register
    uint32_t prescaler = ((SPI1->CR1 & SPI_CR1_BR) >> 3);

    // Map on value of division
    const uint16_t prescaler_table[8] = {2, 4, 8, 16, 32, 64, 128, 256};
    uint32_t spi_clk = pclk / prescaler_table[prescaler];

    return spi_clk;
}

SPI::SPI(port_t port) {
    InitPeripheral(port, get_spi1_clock_freq());
    InitChipSelect();
}

SPI::SPI(port_t port, uint32_t frequency) {
    InitPeripheral(port, frequency);
    InitChipSelect();
}

SPI::SPI(port_t port, uint32_t frequency, GPIO_TypeDef * GPIOx, uint32_t GPIO_Pin) {
    InitPeripheral(port, frequency);
    _csPort = GPIOx;
    _csPin = GPIO_Pin;
    InitChipSelect();
}

SPI::~SPI() {
    DeInitChipSelect();
    DeInitPeripheral();
}

void SPI::InitPeripheral(port_t port, uint32_t frequency) {
    if (port == PORT_SPI1) {
        if (!resSPI1) {
            resSPI1 = new hardware_resource_t();
            resSPI1->port = PORT_SPI1;
            resSPI1->instance = SPI1;
            resSPI1->configured = false;
            resSPI1->instances = 0;
        }
        _hRes = resSPI1;
    }

    _hRes->frequency = frequency;
    _hRes->instances++;

    ConfigurePeripheral();
}

void SPI::ConfigurePeripheral() {
    if (_hRes->configured)
        return;

    // GPIOA clock für SCK (PA5) und MOSI (PB5)
    __HAL_RCC_GPIOA_CLK_ENABLE();
    __HAL_RCC_GPIOB_CLK_ENABLE();
    __HAL_RCC_SPI1_CLK_ENABLE();

    GPIO_InitTypeDef GPIO_InitStruct = {0};

    // SPI1 SCK - PA5
    GPIO_InitStruct.Pin = GPIO_PIN_5;
    GPIO_InitStruct.Mode = GPIO_MODE_AF_PP;
    GPIO_InitStruct.Pull = GPIO_NOPULL;
    GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_VERY_HIGH;
    GPIO_InitStruct.Alternate = GPIO_AF5_SPI1;
    HAL_GPIO_Init(GPIOA, &GPIO_InitStruct);

    // SPI1 MOSI - PB5
    GPIO_InitStruct.Pin = GPIO_PIN_5;
    HAL_GPIO_Init(GPIOB, &GPIO_InitStruct);

    // SPI init
    hspi1.Instance = SPI1;
    hspi1.Init.Mode = SPI_MODE_MASTER;
    hspi1.Init.Direction = SPI_DIRECTION_1LINE;
    hspi1.Init.DataSize = SPI_DATASIZE_8BIT;
    hspi1.Init.CLKPolarity = SPI_POLARITY_LOW;
    hspi1.Init.CLKPhase = SPI_PHASE_1EDGE;
    hspi1.Init.NSS = SPI_NSS_SOFT;
    hspi1.Init.BaudRatePrescaler = SPI_BAUDRATEPRESCALER_16; // adjust to selected prescaler for APB2 peripheral timer
    hspi1.Init.FirstBit = SPI_FIRSTBIT_MSB;
    hspi1.Init.TIMode = SPI_TIMODE_DISABLE;
    hspi1.Init.CRCCalculation = SPI_CRCCALCULATION_DISABLE;
    hspi1.Init.CRCPolynomial = 10;
    HAL_SPI_Init(&hspi1);

    _hRes->configured = true;
}

void SPI::InitChipSelect() {
    if (!_csPort)
        return;

    GPIO_InitTypeDef GPIO_InitStruct = {0};
    GPIO_InitStruct.Pin = _csPin;
    GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
    GPIO_InitStruct.Pull = GPIO_NOPULL;
    GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
    HAL_GPIO_Init(_csPort, &GPIO_InitStruct);

    HAL_GPIO_WritePin(_csPort, _csPin, GPIO_PIN_SET); // inaktiv high
}

void SPI::DeInitPeripheral() {
    _hRes->instances--;
    if (_hRes->instances == 0) {
        HAL_SPI_DeInit(&hspi1);
        _hRes->configured = false;
    }
}

void SPI::DeInitChipSelect() {
    if (!_csPort)
        return;
    HAL_GPIO_DeInit(_csPort, _csPin);
}

bool SPI::Write(uint8_t reg, uint8_t value) {
    return WriteBlocking(reg, &value, 1);
}

bool SPI::Write(uint8_t reg, uint8_t * buffer, uint8_t writeLength) {
    return WriteBlocking(reg, buffer, writeLength);
}

uint8_t SPI::Read(uint8_t reg) {
    uint8_t data = 0x00;
    ReadBlocking(reg, &data, 1);
    return data;
}

bool SPI::Read(uint8_t reg, uint8_t * buffer, uint8_t readLength) {
    return ReadBlocking(reg, buffer, readLength);
}

bool SPI::WriteBlocking(uint8_t reg, uint8_t * buffer, uint8_t writeLength) {
    HAL_GPIO_WritePin(_csPort, _csPin, GPIO_PIN_RESET);
    HAL_SPI_Transmit(&hspi1, &reg, 1, HAL_MAX_DELAY);
    HAL_SPI_Transmit(&hspi1, buffer, writeLength, HAL_MAX_DELAY);
    HAL_GPIO_WritePin(_csPort, _csPin, GPIO_PIN_SET);
    return true;
}

bool SPI::ReadBlocking(uint8_t reg, uint8_t * buffer, uint8_t readLength) {
    HAL_GPIO_WritePin(_csPort, _csPin, GPIO_PIN_RESET);
    HAL_SPI_Transmit(&hspi1, &reg, 1, HAL_MAX_DELAY);
    HAL_SPI_Receive(&hspi1, buffer, readLength, HAL_MAX_DELAY);
    HAL_GPIO_WritePin(_csPort, _csPin, GPIO_PIN_SET);
    return true;
}

/*
// === Display Control Pins ===
void ILI9341_CS_Low()  { GPIOD->ODR &= ~(1 << 6); }
void ILI9341_CS_High() { GPIOD->ODR |=  (1 << 6); }
void ILI9341_DC_Low()  { GPIOD->ODR &= ~(1 << 7); }
void ILI9341_DC_High() { GPIOD->ODR |=  (1 << 7); }
void ILI9341_Reset() {
    GPIOD->ODR &= ~(1 << 3);
    for (volatile int i = 0; i < 100000; ++i);
    GPIOD->ODR |= (1 << 3);
    for (volatile int i = 0; i < 100000; ++i);
}

void ILI9341_WriteCommand(uint8_t cmd) {
    ILI9341_CS_Low();
    ILI9341_DC_Low();
    SPI1_Write(cmd);
    ILI9341_CS_High();
}

void ILI9341_WriteData(uint8_t data) {
    ILI9341_CS_Low();
    ILI9341_DC_High();
    SPI1_Write(data);
    ILI9341_CS_High();
}

void ILI9341_Init(void) {
    ILI9341_Reset();
    ILI9341_WriteCommand(0x01); // Software Reset (Gewollt?)
    for (volatile int i = 0; i < 100000; ++i);
    // TODO: Weitere Init-Befehle je nach Display
}

*/
