/*
 * functions.c
 *
 *  Created on: Jun 16, 2025
 *      Author: AlexP
 */

#include "functions.h"
#include "main.h"
#include <stdbool.h>
#include <math.h>
#include <stdio.h>
#include <stdlib.h>

/*
//Precharge Relais Ansteuerung

void Precharge(void)
  {
	  HAL_GPIO_TogglePin(GPIOD, GPIO_PIN_0);   // Setzt PIN PD0 auf 1 (high)
  }

//Relais + Ansteuerung

void Relais_plus(void)
  {
	  HAL_GPIO_TogglePin(GPIOD, GPIO_PIN_1);   // Setzt PIN PD1 auf 1 (high)
  }

//Relais - Ansteuerung

void Relais_minus(void)
  {
	  HAL_GPIO_TogglePin(GPIOD, GPIO_PIN_2);   // Setzt PIN PD2 auf 1 (high)
  }
*/

//Voltage_Measurement

float Voltage_Measurement(float Vout_measured) {

	float Vout_corrected = 0;

    //Spannungskorrektur
    Vout_corrected = 2.5 * Vout_measured;

    return Vout_corrected;
}

//Temp_Measurment

float Temp_Measurement(float Vout_measured) {

    float Rfix = 10000.0f;
    float Vcc = 5.0f; // Versorgung des Spannungsteilers
    float Vout_corrected = 0;
    float Rntc = 0;
    float tempK = 0;
    float T0 = 298.15f;  // 25 °C in Kelvin
    float R0 = 10000.0f; // 10k bei 25 °C
    float B  = 3892.0f;  // Beta-Wert

    //Spannungskorrektur
    Vout_corrected = 2 * Vout_measured;

    //Berechnung R_NTC
    Rntc = (Vout_corrected * Rfix / (Vcc - Vout_corrected));

    //Berechnung Temperatur in K
    tempK = 1.0f / ((1.0f / T0) + (1.0f / B) * log(Rntc / R0));
    return tempK - 273.15f; // Umrechnung in °C
}


//Current_Measurement

float Current_Measurement(float Vout_measured){

	float Voffset = 2.8f;
	float G = 0.0052f;
	float current = 0;

	//Berechnung Strom
	current = (Vout_measured-Voffset)/G;

	return current;
}

//ADC Bitauflösung in Voltage umrechnen

float Bit_to_Voltage(uint16_t adc_value)
{
    return ((float)adc_value / 4095.0f) * 3.3f;
}

//Fehler Limits

void check_limits(float* avg_values, char typ, int size, float min, float max) {

    for (int i = 0; i < size; i++) {
        if (avg_values[i] < min || avg_values[i] > max) {
        	switch(typ){
        	case 'a': {
        	    acc_error = true;
        		temperature_error = true;
        		break;
        	}

        	case 'b': {
        		acc_error = true;
        		voltage_error = true;
        		break;
        	}

        	case 'c': {
        		acc_error = true;
        		current_error = true;
        		break;
        	}
        	}
        }
    }
}

//Callback Function for DMA complete cycle
void HAL_ADC_ConvCpltCallback(ADC_HandleTypeDef* hadc){

	if (hadc->Instance == ADC1)
	  	 	{

			//Temperatur berechnen
		    tempValues[0] = Bit_to_Voltage(adcValue_temp[0]);
		    tempValues[1] = Bit_to_Voltage(adcValue_temp[1]);
		    tempValues[2] = Bit_to_Voltage(adcValue_temp[2]);
		    tempValues[3] = Bit_to_Voltage(adcValue_temp[3]);
		    tempValues[4] = Bit_to_Voltage(adcValue_temp[4]);
		    tempValues[5] = Bit_to_Voltage(adcValue_temp[5]);

		    //memcpy(avg_tempValues, push(tempValues, 'a'), 6*sizeof(float) );
		    //avg_tempValues = push(tempValues, 'a');

		    //Schleife
  	 		//check_limits(avg_tempValues, 6, 'a', ThresholdTempLow, ThresholdTempHigh);

  	 		TempMeasurement1 = Temp_Measurement(tempValues[0]);
			TempMeasurement2 = Temp_Measurement(tempValues[1]);
			TempMeasurement3 = Temp_Measurement(tempValues[2]);
			TempMeasurement4 = Temp_Measurement(tempValues[3]);
			TempMeasurement5 = Temp_Measurement(tempValues[4]);
			TempMeasurement6 = Temp_Measurement(tempValues[5]);
	  	 	}

  	 if (hadc->Instance == ADC2)
  	 	    {
  		 	// Spannungsberechnung
  	 		voltageValues[0] = Bit_to_Voltage(adcValue_voltage[0]);
  	 		voltageValues[1] = Bit_to_Voltage(adcValue_voltage[1]);
  	 		voltageValues[2] = Bit_to_Voltage(adcValue_voltage[2]);
  	 		voltageValues[3] = Bit_to_Voltage(adcValue_voltage[3]);

  	 		float* tmp;
  	 		tmp = push(voltageValues, 'b');
  	 		for(int i= 0; i<4; i++){
  	 			avg_voltageValues[i] = tmp[i];
  	 		}
  	 		//avg_voltageValues = push(voltageValues, 'b');

  	 		//Schleife
  	 		check_limits(avg_voltageValues, 4, 'b', ThresholdVoltageLow, ThresholdVoltageHigh);

  	 		//VoltageWerte an globale Variable übergeben
  	 		VoltageMeasurement1 = Voltage_Measurement(avg_voltageValues[0]);
  	 		VoltageMeasurement2 = Voltage_Measurement(avg_voltageValues[1]);
  	 		VoltageMeasurement3 = Voltage_Measurement(avg_voltageValues[2]);
  	 		VoltageMeasurement4 = Voltage_Measurement(avg_voltageValues[3]);



  	 	      }

  	if (hadc->Instance == ADC3)
  	  	 	  {
  	  		 	 //Stromberechnung

  					currentValue = Bit_to_Voltage(adcValue_current_display[0]);


  					avg_currentValue = push(&currentValue, 'c')[0];

  					//Schleife
  					check_limits(&avg_currentValue, 'c', 1, ThresholdCurrentLow, ThresholdCurrentHigh);


  					CurrentMeasurement = Current_Measurement(avg_currentValue);

  					//Display Auswertung
  					touchdisplay_x = adcValue_current_display[1];
  					touchdisplay_y = adcValue_current_display[2];

  	  	 	      }
}

//Buffer functions
//##################################################
// Ring Buffer Struct
//##################################################


void buff_push_val(struct RingBuffer* buff, float val) {
    if (buff->full == 1) {
        buff->i %= 10;
        buff->sum -= buff->arr[buff->i];
        buff->arr[buff->i] = val;
        buff->sum += buff->arr[buff->i++];
    } else {
        buff->arr[buff->i] = val;
        buff->sum += buff->arr[buff->i++];

        if (buff->i >= 9) {
            buff->full = 1;
        }
    }
}

float buff_get_avg(struct RingBuffer* buff) {
    return buff->full == 1 ? buff->sum / 10 : buff->sum / (buff->i);
}

//##################################################
// Module Struct
//##################################################



struct Module* create_module(int size) {
    struct Module* module = (struct Module*) malloc(sizeof(struct Module));
    module->buff = (struct RingBuffer**) malloc(sizeof(struct RingBuffer*) * size);
    module->avg = (float*) malloc(sizeof(float) * size);
    module->size = size;

    for (int i = 0; i < size; i++) {
        module->buff[i] = (struct RingBuffer*) malloc(sizeof(struct RingBuffer));
        module->buff[i]->arr = (float*) malloc(sizeof(float) * 10);
        module->buff[i]->sum = 0;
        module->buff[i]->full = 0;
        module->buff[i]->i = 0;
    }

    return module;
}

void mod_push(struct Module* mod, float* arr) {
    for (int i = 0; i < mod->size; i++) {
        buff_push_val(mod->buff[i], arr[i]);
        mod->avg[i] = buff_get_avg(mod->buff[i]);
    }
}

void free_mod(struct Module* mod) {
    for (int i = 0; i < mod->size; i++) {
        free(mod->buff[i]->arr);
        free(mod->buff[i]);
    }

    free(mod->avg);
    free(mod->buff);
    free(mod);
}

//##################################################
// Modules
//##################################################

struct Module* mod1;
struct Module* mod2;
struct Module* mod3;

void initialize_modules() {
    mod1 = create_module(6); //Temperature a
    mod2 = create_module(4); //Voltage b
    mod3 = create_module(1); //current c
}

void free_modules() {
    free_mod(mod1);
    free_mod(mod2);
    free_mod(mod3);
}//

float* push(float* arr, char type) {
    switch (type) {
        case 'a':
            mod_push(mod1, arr);
            return mod1->avg;
        case 'b':
            mod_push(mod2, arr);
            return mod2->avg;
        case 'c':
            mod_push(mod3, arr);
            return mod3->avg;
        default:
            return NULL;
    }
}
// Buffer end







