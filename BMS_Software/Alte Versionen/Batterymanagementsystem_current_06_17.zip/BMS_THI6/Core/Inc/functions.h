/*
 * functions.h
 *
 *  Created on: Jun 16, 2025
 *      Author: AlexP
 */


#ifdef __cplusplus
extern "C" {
#endif


#ifndef INC_FUNCTIONS_H_
#define INC_FUNCTIONS_H_

#include "main.h"
#include <stdbool.h>
#include <string.h>


//Relais_control
void Precharge(void);
void Relais_plus(void);
void Relais_minus(void);

//Voltage_Measurment
float Voltage_Measurement(float Vout_measured);

//Temp_Measurment
float Temp_Measurement(float Vout_measured);

//Current_Measurment
float Current_Measurement(float Vout_measured);

//12Bit to Voltage
float Bit_to_Voltage(uint16_t adc_value);

//Treshhold Vergleich
void check_limits(float* avg_values, char typ, int size, float min, float max);

//Callbackfunction
void HAL_ADC_ConvCpltCallback(ADC_HandleTypeDef* hadc);

#endif /* INC_FUNCTIONS_H_ */

// Buffer Functions
struct Module {
    struct RingBuffer** buff;
    float* avg;
    int size;
};

struct RingBuffer {
    float* arr;
    float sum;
    char full;
    int i;
};

void buff_push_val(struct RingBuffer* buff, float val);

float buff_get_avg(struct RingBuffer* buff);

struct Module* create_module(int size);

void mod_push(struct Module* mod, float* arr);

void free_mod(struct Module* mod);

void initialize_modules(void);

void free_modules();

float* push(float* arr, char type);

//buffer end


#ifdef __cplusplus
}
#endif

