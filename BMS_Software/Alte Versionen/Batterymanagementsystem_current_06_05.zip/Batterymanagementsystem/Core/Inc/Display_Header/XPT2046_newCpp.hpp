/*
 * XPT2046_newCpp.hpp
 *
 *  Created on: May 31, 2025
 *      Author: kevin
 */

#ifndef XPT2046_TOUCH_HPP
#define XPT2046_TOUCH_HPP

#include "stm32f4xx_hal.h" // Passe dies entsprechend deinem STM32-Modell an

class XPT2046Touch {
public:
    XPT2046Touch(SPI_HandleTypeDef* hspi, GPIO_TypeDef* csPort, uint16_t csPin);
    void begin();
    bool isTouched();
    bool getTouch(uint16_t& x, uint16_t& y);

private:
    uint16_t readCoordinate(uint8_t command);
    void select();
    void deselect();

    SPI_HandleTypeDef* _hspi;
    GPIO_TypeDef* _csPort;
    uint16_t _csPin;
};

#endif // XPT2046_TOUCH_HPP
