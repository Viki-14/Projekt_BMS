/*
 * functions.h
 *
 *  Created on: May, 2025
 *      Author: AlexP
 */

#include "main.h"
#include <stdbool.h>

#ifndef INC_FUNCTIONS_H_
#define INC_FUNCTIONS_H_

//Externe Variablen für Voltage
extern uint16_t adcValue_voltage[4];
extern float voltageValues[4];
extern float VoltageMeasurement1;
extern float VoltageMeasurement2;
extern float VoltageMeasurement3;
extern float VoltageMeasurement4;

//Externe Variablen für Current
extern float CurrentMeasurement;
extern uint16_t adcValue_current_display[3];
extern float currentValue;


//Relais_control
void Precharge(void);
void Relais_plus(void);
void Relais_minus(void);

//Voltage_Measurment
float Voltage_Measurement(float Vout_measured);

//Temp_Measurment
float Temp_Measurement(float Vout_measured);

//Current_Measurment
float Current_Measurement(float Vout_measured);

//12Bit to Voltage
float Bit_to_Voltage(uint16_t adc_value);

//Callbackfunction
void HAL_ADC_ConvCpltCallback(ADC_HandleTypeDef* hadc);

#endif /* INC_FUNCTIONS_H_ */

// Buffer Functions
struct Module {
    struct RingBuffer** buff;
    float* avg;
    int size;
};

struct RingBuffer {
    float* arr;
    float sum;
    char full;
    int i;
};

void buff_push_val(struct RingBuffer* buff, float val);

float buff_get_avg(struct RingBuffer* buff);

struct Module* create_module(int size);

void mod_push(struct Module* mod, float* arr);

void free_mod(struct Module* mod);

void initialize_modules();

void free_modules();

float* push(float* arr, char type);



//buffer end
