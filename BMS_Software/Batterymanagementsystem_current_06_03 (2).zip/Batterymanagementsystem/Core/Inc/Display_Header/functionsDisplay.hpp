/*
 * functionsDisplay.hpp
 *
 *  Created on: May 27, 2025
 *      Author: kevin
 */

#ifndef INC_FUNCTIONSDISPLAY_HPP_
#define INC_FUNCTIONSDISPLAY_HPP_

#include <stdint.h>
#include <stddef.h>

class functionsDisplay{

	struct TouchPoint{
		uint16_t x;
		uint16_t y;
		uint16_t z;
	};
private:
	//State
	typedef enum {
	    STATE_INIT,
	    STATE_FAULT,
	    STATE_IDLE,
	    STATE_PRECHARGE,
	    STATE_ACTIVE
	} SystemState;
public:
	void Display_Configuration(void);
	void drawUI(void);
	void drawVoltagesUI(float VoltageMeasurement1, float VoltageMeasurement2, float VoltageMeasurement3,float VoltageMeasurement4, float VoltageMeasurementTotal);
	void drawTemperaturesUI(float TempMeasurement1, float TempMeasurement2, float TempMeasurement3, float TempMeasurement4, float TempMeasurement5, float TempMeasurement6);
	void drawCurrentUI(float CurrentMeasurement);
	void drawStatusUI(SystemState State);
	void drawRuntimeUI(uint32_t runTime_s);
	void setupButtons();
	TouchPoint getTouch();
	void checkButtons();
};
#endif /* INC_FUNCTIONSDISPLAY_HPP_ */
