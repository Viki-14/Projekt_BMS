/*
 * IO.h
 *
 * Link: https://github.com/mindThomas/STM32-libraries/blob/master/Periphirals/STM32F4/IO/IO.h
 *
 *  Created on: May 18, 2025
 *      Author: kevin
 */

/* Copyright (C) 2018-2019 Thomas Jespersen, TKJ Electronics. All rights reserved.
 *
 * This program is free software: you can redistribute it and/or modify it
 * under the terms of the MIT License
 *
 * This program is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the MIT License for further details.
 *
 * Contact information
 * ------------------------------------------
 * Thomas Jespersen, TKJ Electronics
 * Web      :  http://www.tkjelectronics.dk
 * e-mail   :  thomasj@tkjelectronics.dk
 * ------------------------------------------
 */

#ifndef PERIPHIRALS_IO_HPP
#define PERIPHIRALS_IO_HPP

#include <Display_Header/cmsis_os.hpp> // for semaphore support; Notwendigkeit von FreeRTOS
#include "stm32f4xx_hal.h"
/*
#ifdef USE_FREERTOS
#include "cmsis_os.h" // for memory allocation (for the buffer) and callback
#endif
*/

class IO
{
	public:

		typedef enum interrupt_trigger_t {
			IO_TRIGGER_RISING = 0,
			IO_TRIGGER_FALLING,
			IO_TRIGGER_BOTH,
		} interrupt_trigger_t;


		typedef enum pull_t {
			PULL_NONE = 0,
			PULL_UP,
			PULL_DOWN,
		} pull_t;

	public:
		IO(GPIO_TypeDef * GPIOx, uint32_t GPIO_Pin); // configure as output
		IO(GPIO_TypeDef * GPIOx, uint32_t GPIO_Pin, pull_t pull); // configure as input
		~IO();

		void RegisterInterrupt(interrupt_trigger_t trigger, osSemaphoreId semaphore); 	//changed SemaphoreHandle_t to osSemaphoreId
		void RegisterInterrupt(interrupt_trigger_t trigger, void (*InterruptCallback)(void * params), void * callbackParams);
		void DeregisterInterrupt();

		void Set(bool state);
		bool Read();
		void High();
		void Low();
		void Toggle();

		void ChangeToInput(pull_t pull);
		void ChangeToOutput(bool state = false);
		void ChangeToOpenDrain(bool state = false);

	private:
		void ConfigurePin(GPIO_TypeDef * GPIOx, uint32_t GPIO_Pin, bool isInput, bool isOpenDrain, pull_t pull);

	public:
		void (*_InterruptCallback)(void * params);
		void * _InterruptCallbackParams;
		osSemaphoreId _InterruptSemaphore;	//changed SemaphoreHandle_t to osSemaphoreId

		static IO * interruptObjects[16]; // we only have 16 interrupt lines

	private:
		GPIO_TypeDef * _GPIO;
		uint32_t _pin;
		bool _isInput;
		bool _isOpenDrain;
		pull_t _pull;

	private:
		void ConfigureInterrupt(interrupt_trigger_t level);
		void DisableInterrupt();

	public:
		static void InterruptHandler(IO * io);
};


#endif
