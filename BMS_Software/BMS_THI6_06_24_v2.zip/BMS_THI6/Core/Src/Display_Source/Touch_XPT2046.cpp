/*
 * Touch_XPT2046.cpp
 *
 *  Created on: Jun 17, 2025
 *      Author: kevin
 */

#include "Display_Header/Touch_XPT2046.h"

#define CMD_X 0xD0
#define CMD_Y 0x90

XPT2046Touch::XPT2046Touch(SPI_HandleTypeDef* hspi, GPIO_TypeDef* csPort, uint16_t csPin)
    : _hspi(hspi), _csPort(csPort), _csPin(csPin) {}

void XPT2046Touch::begin() {
    deselect();
}

bool XPT2046Touch::isTouched() {
    // Hier kannst du den T_IRQ-Pin abfragen, falls vorhanden
    // Andernfalls immer true zurückgeben
    return true;
}

bool XPT2046Touch::getTouch(uint16_t& x, uint16_t& y) {
    if (!isTouched()) return false;

    select();
    x = readCoordinate(CMD_X);
    y = readCoordinate(CMD_Y);
    deselect();

    return true;
}

uint16_t XPT2046Touch::readCoordinate(uint8_t command) {
    uint8_t tx[3] = { command, 0x00, 0x00 };
    uint8_t rx[3] = { 0 };

    HAL_SPI_TransmitReceive(_hspi, tx, rx, 3, HAL_MAX_DELAY);

    uint16_t value = ((rx[1] << 8) | rx[2]) >> 3;
    return value;
}

void XPT2046Touch::select() {
    HAL_GPIO_WritePin(_csPort, _csPin, GPIO_PIN_RESET);
}

void XPT2046Touch::deselect() {
    HAL_GPIO_WritePin(_csPort, _csPin, GPIO_PIN_SET);
}





