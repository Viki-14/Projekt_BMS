/*
 * functions.h
 *
 *  Created on: May, 2025
 *      Author: AlexP
 */

#include "main.h"
#include <stdbool.h>

#ifndef INC_FUNCTIONS_H_
#define INC_FUNCTIONS_H_

//Relais_control
void Relais_control(void);

//Voltage_Measurment
void Voltage_Measurement(void);

//Temp_Measurment
float Temp_Measurement(float Vout_measured);

//Current_Measurment
void Current_Measurement(void);
void Display_Configuration(void);

#endif /* INC_FUNCTIONS_H_ */
