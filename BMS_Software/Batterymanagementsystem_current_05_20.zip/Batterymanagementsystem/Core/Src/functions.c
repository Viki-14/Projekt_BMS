/*
 * functions.c
 *
 *  Created on: May, 2025
 *      Author: AlexP
 */

#include "functions.h"
#include <stdbool.h>
#include <math.h>

//Precharge Relais Ansteuerung

void Relais_control(void)
  {
	  HAL_GPIO_TogglePin(GPIOD, GPIO_PIN_0);   // Setzt PIN PD0 auf 1 (high)
  }


//Voltage_Measurement



//Temp_Measurment

float Temp_Measurement(float Vout_measured) {

    float Rfix = 10000.0f;
    float Vcc = 5.0f; // Versorgung des Spannungsteilers
    float Vout_corrected = 0;
    float Rntc = 0;
    float tempK = 0;
    float T0 = 298.15f;  // 25 °C in Kelvin
    float R0 = 10000.0f; // 10k bei 25 °C
    float B  = 3892.0f;  // Beta-Wert

    //Spannungskorrektur
    Vout_corrected = 2 * Vout_measured;

    //Berechnung R_NTC
    Rntc = (Vout_corrected * Rfix / Vcc - Vout_corrected) - Rfix;

    tempK = 1.0f / ((1.0f / T0) + (1.0f / B) * log(Rntc / R0));
    return tempK - 273.15f; // Umrechnung in °C
}


//Current_Measurement





//Display_Configuration





